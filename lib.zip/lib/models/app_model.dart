import 'package:flutter/material.dart';
import 'package:get/get.dart';

class InitialvalModel{
  String? initialval;

  InitialvalModel({required this.initialval});

}
